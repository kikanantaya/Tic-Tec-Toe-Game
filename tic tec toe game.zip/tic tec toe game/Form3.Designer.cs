﻿namespace tic_tec_toe_game
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.k1 = new System.Windows.Forms.Button();
            this.k2 = new System.Windows.Forms.Button();
            this.k3 = new System.Windows.Forms.Button();
            this.t1 = new System.Windows.Forms.Button();
            this.t2 = new System.Windows.Forms.Button();
            this.t3 = new System.Windows.Forms.Button();
            this.u1 = new System.Windows.Forms.Button();
            this.u2 = new System.Windows.Forms.Button();
            this.u3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Draw_count = new System.Windows.Forms.Label();
            this.You_win_count = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.o_win_count = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // k1
            // 
            this.k1.BackColor = System.Drawing.Color.Transparent;
            this.k1.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.k1.ForeColor = System.Drawing.Color.Black;
            this.k1.Location = new System.Drawing.Point(78, 122);
            this.k1.Name = "k1";
            this.k1.Size = new System.Drawing.Size(77, 68);
            this.k1.TabIndex = 0;
            this.k1.UseVisualStyleBackColor = false;
            this.k1.Click += new System.EventHandler(this.button_click);
            // 
            // k2
            // 
            this.k2.BackColor = System.Drawing.Color.Transparent;
            this.k2.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.k2.ForeColor = System.Drawing.Color.Black;
            this.k2.Location = new System.Drawing.Point(161, 122);
            this.k2.Name = "k2";
            this.k2.Size = new System.Drawing.Size(77, 68);
            this.k2.TabIndex = 1;
            this.k2.UseVisualStyleBackColor = false;
            this.k2.Click += new System.EventHandler(this.button_click);
            // 
            // k3
            // 
            this.k3.BackColor = System.Drawing.Color.Transparent;
            this.k3.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.k3.ForeColor = System.Drawing.Color.Black;
            this.k3.Location = new System.Drawing.Point(244, 122);
            this.k3.Name = "k3";
            this.k3.Size = new System.Drawing.Size(77, 68);
            this.k3.TabIndex = 2;
            this.k3.UseVisualStyleBackColor = false;
            this.k3.Click += new System.EventHandler(this.button_click);
            // 
            // t1
            // 
            this.t1.BackColor = System.Drawing.Color.Transparent;
            this.t1.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t1.ForeColor = System.Drawing.Color.Black;
            this.t1.Location = new System.Drawing.Point(78, 196);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(77, 68);
            this.t1.TabIndex = 3;
            this.t1.UseVisualStyleBackColor = false;
            this.t1.Click += new System.EventHandler(this.button_click);
            // 
            // t2
            // 
            this.t2.BackColor = System.Drawing.Color.Transparent;
            this.t2.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t2.ForeColor = System.Drawing.Color.Black;
            this.t2.Location = new System.Drawing.Point(161, 196);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(77, 68);
            this.t2.TabIndex = 4;
            this.t2.UseVisualStyleBackColor = false;
            this.t2.Click += new System.EventHandler(this.button_click);
            // 
            // t3
            // 
            this.t3.BackColor = System.Drawing.Color.Transparent;
            this.t3.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t3.ForeColor = System.Drawing.Color.Black;
            this.t3.Location = new System.Drawing.Point(244, 196);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(77, 68);
            this.t3.TabIndex = 5;
            this.t3.UseVisualStyleBackColor = false;
            this.t3.Click += new System.EventHandler(this.button_click);
            // 
            // u1
            // 
            this.u1.BackColor = System.Drawing.Color.Transparent;
            this.u1.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.u1.ForeColor = System.Drawing.Color.Black;
            this.u1.Location = new System.Drawing.Point(78, 268);
            this.u1.Name = "u1";
            this.u1.Size = new System.Drawing.Size(77, 68);
            this.u1.TabIndex = 6;
            this.u1.UseVisualStyleBackColor = false;
            this.u1.Click += new System.EventHandler(this.button_click);
            // 
            // u2
            // 
            this.u2.BackColor = System.Drawing.Color.Transparent;
            this.u2.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.u2.ForeColor = System.Drawing.Color.Black;
            this.u2.Location = new System.Drawing.Point(161, 270);
            this.u2.Name = "u2";
            this.u2.Size = new System.Drawing.Size(77, 68);
            this.u2.TabIndex = 7;
            this.u2.UseVisualStyleBackColor = false;
            this.u2.Click += new System.EventHandler(this.button_click);
            // 
            // u3
            // 
            this.u3.BackColor = System.Drawing.Color.Transparent;
            this.u3.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.u3.ForeColor = System.Drawing.Color.Black;
            this.u3.Location = new System.Drawing.Point(244, 268);
            this.u3.Name = "u3";
            this.u3.Size = new System.Drawing.Size(77, 68);
            this.u3.TabIndex = 8;
            this.u3.UseVisualStyleBackColor = false;
            this.u3.Click += new System.EventHandler(this.button_click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label1.Font = new System.Drawing.Font("Angsana New", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(102, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 66);
            this.label1.TabIndex = 9;
            this.label1.Text = "Singleplayer";
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.aToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(393, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.newGameToolStripMenuItem.Text = "New Game";
            this.newGameToolStripMenuItem.Click += new System.EventHandler(this.newGameToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aToolStripMenuItem
            // 
            this.aToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.aToolStripMenuItem.Name = "aToolStripMenuItem";
            this.aToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.aToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // Draw_count
            // 
            this.Draw_count.AutoSize = true;
            this.Draw_count.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Draw_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Draw_count.Location = new System.Drawing.Point(271, 478);
            this.Draw_count.Name = "Draw_count";
            this.Draw_count.Size = new System.Drawing.Size(30, 31);
            this.Draw_count.TabIndex = 22;
            this.Draw_count.Text = "0";
            // 
            // You_win_count
            // 
            this.You_win_count.AutoSize = true;
            this.You_win_count.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.You_win_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.You_win_count.Location = new System.Drawing.Point(271, 374);
            this.You_win_count.Name = "You_win_count";
            this.You_win_count.Size = new System.Drawing.Size(30, 31);
            this.You_win_count.TabIndex = 20;
            this.You_win_count.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Font = new System.Drawing.Font("Angsana New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(72, 472);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 37);
            this.label4.TabIndex = 19;
            this.label4.Text = "Draw Count";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Angsana New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(72, 368);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 37);
            this.label2.TabIndex = 17;
            this.label2.Text = "X You win Count";
            // 
            // o_win_count
            // 
            this.o_win_count.AutoSize = true;
            this.o_win_count.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.o_win_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.o_win_count.Location = new System.Drawing.Point(271, 425);
            this.o_win_count.Name = "o_win_count";
            this.o_win_count.Size = new System.Drawing.Size(30, 31);
            this.o_win_count.TabIndex = 24;
            this.o_win_count.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Angsana New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(72, 419);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 37);
            this.label3.TabIndex = 23;
            this.label3.Text = "O win Count";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::tic_tec_toe_game.Properties.Resources._14236953_Madera_de_fondo_de_material_para_el_papel_pintado_vintage_Foto_de_archivo;
            this.ClientSize = new System.Drawing.Size(393, 532);
            this.Controls.Add(this.o_win_count);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Draw_count);
            this.Controls.Add(this.You_win_count);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.u3);
            this.Controls.Add(this.u2);
            this.Controls.Add(this.u1);
            this.Controls.Add(this.t3);
            this.Controls.Add(this.t2);
            this.Controls.Add(this.t1);
            this.Controls.Add(this.k3);
            this.Controls.Add(this.k2);
            this.Controls.Add(this.k1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button k1;
        private System.Windows.Forms.Button k2;
        private System.Windows.Forms.Button k3;
        private System.Windows.Forms.Button t1;
        private System.Windows.Forms.Button t2;
        private System.Windows.Forms.Button t3;
        private System.Windows.Forms.Button u1;
        private System.Windows.Forms.Button u2;
        private System.Windows.Forms.Button u3;
        private System.Windows.Forms.Label label1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Label Draw_count;
        private System.Windows.Forms.Label You_win_count;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label o_win_count;
        private System.Windows.Forms.Label label3;
    }
}