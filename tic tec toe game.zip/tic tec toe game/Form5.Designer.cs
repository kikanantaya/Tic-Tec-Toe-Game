﻿namespace tic_tec_toe_game
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.k1 = new System.Windows.Forms.Button();
            this.k2 = new System.Windows.Forms.Button();
            this.k3 = new System.Windows.Forms.Button();
            this.t1 = new System.Windows.Forms.Button();
            this.t2 = new System.Windows.Forms.Button();
            this.t3 = new System.Windows.Forms.Button();
            this.u1 = new System.Windows.Forms.Button();
            this.u2 = new System.Windows.Forms.Button();
            this.u3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.x_win_count = new System.Windows.Forms.Label();
            this.o_win_count = new System.Windows.Forms.Label();
            this.draw_count = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Angsana New", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(107, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 66);
            this.label1.TabIndex = 0;
            this.label1.Text = "Multiplayer";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // k1
            // 
            this.k1.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.k1.ForeColor = System.Drawing.Color.Black;
            this.k1.Location = new System.Drawing.Point(76, 104);
            this.k1.Name = "k1";
            this.k1.Size = new System.Drawing.Size(77, 68);
            this.k1.TabIndex = 1;
            this.k1.UseVisualStyleBackColor = true;
            this.k1.Click += new System.EventHandler(this.button_click);
            this.k1.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.k1.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // k2
            // 
            this.k2.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.k2.ForeColor = System.Drawing.Color.Black;
            this.k2.Location = new System.Drawing.Point(159, 104);
            this.k2.Name = "k2";
            this.k2.Size = new System.Drawing.Size(77, 68);
            this.k2.TabIndex = 2;
            this.k2.UseVisualStyleBackColor = true;
            this.k2.Click += new System.EventHandler(this.button_click);
            this.k2.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.k2.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // k3
            // 
            this.k3.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.k3.ForeColor = System.Drawing.Color.Black;
            this.k3.Location = new System.Drawing.Point(242, 104);
            this.k3.Name = "k3";
            this.k3.Size = new System.Drawing.Size(77, 68);
            this.k3.TabIndex = 3;
            this.k3.UseVisualStyleBackColor = true;
            this.k3.Click += new System.EventHandler(this.button_click);
            this.k3.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.k3.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // t1
            // 
            this.t1.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t1.ForeColor = System.Drawing.Color.Black;
            this.t1.Location = new System.Drawing.Point(76, 178);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(77, 68);
            this.t1.TabIndex = 4;
            this.t1.UseVisualStyleBackColor = true;
            this.t1.Click += new System.EventHandler(this.button_click);
            this.t1.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.t1.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // t2
            // 
            this.t2.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t2.ForeColor = System.Drawing.Color.Black;
            this.t2.Location = new System.Drawing.Point(159, 178);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(77, 68);
            this.t2.TabIndex = 5;
            this.t2.UseVisualStyleBackColor = true;
            this.t2.Click += new System.EventHandler(this.button_click);
            this.t2.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.t2.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // t3
            // 
            this.t3.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t3.ForeColor = System.Drawing.Color.Black;
            this.t3.Location = new System.Drawing.Point(242, 178);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(77, 68);
            this.t3.TabIndex = 6;
            this.t3.UseVisualStyleBackColor = true;
            this.t3.Click += new System.EventHandler(this.button_click);
            this.t3.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.t3.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // u1
            // 
            this.u1.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.u1.ForeColor = System.Drawing.Color.Black;
            this.u1.Location = new System.Drawing.Point(76, 252);
            this.u1.Name = "u1";
            this.u1.Size = new System.Drawing.Size(77, 68);
            this.u1.TabIndex = 7;
            this.u1.UseVisualStyleBackColor = true;
            this.u1.Click += new System.EventHandler(this.button_click);
            this.u1.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.u1.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // u2
            // 
            this.u2.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.u2.ForeColor = System.Drawing.Color.Black;
            this.u2.Location = new System.Drawing.Point(159, 252);
            this.u2.Name = "u2";
            this.u2.Size = new System.Drawing.Size(77, 68);
            this.u2.TabIndex = 8;
            this.u2.UseVisualStyleBackColor = true;
            this.u2.Click += new System.EventHandler(this.button_click);
            this.u2.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.u2.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // u3
            // 
            this.u3.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.u3.ForeColor = System.Drawing.Color.Black;
            this.u3.Location = new System.Drawing.Point(242, 252);
            this.u3.Name = "u3";
            this.u3.Size = new System.Drawing.Size(77, 68);
            this.u3.TabIndex = 9;
            this.u3.UseVisualStyleBackColor = true;
            this.u3.Click += new System.EventHandler(this.button_click);
            this.u3.DragEnter += new System.Windows.Forms.DragEventHandler(this.button_enter);
            this.u3.DragLeave += new System.EventHandler(this.button_leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Angsana New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(69, 351);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 37);
            this.label2.TabIndex = 11;
            this.label2.Text = "X win Count";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Angsana New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(70, 414);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 37);
            this.label3.TabIndex = 12;
            this.label3.Text = "O win Count";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Angsana New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(69, 478);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 37);
            this.label4.TabIndex = 13;
            this.label4.Text = "Draw Count";
            // 
            // x_win_count
            // 
            this.x_win_count.AutoSize = true;
            this.x_win_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.x_win_count.Location = new System.Drawing.Point(253, 357);
            this.x_win_count.Name = "x_win_count";
            this.x_win_count.Size = new System.Drawing.Size(30, 31);
            this.x_win_count.TabIndex = 14;
            this.x_win_count.Text = "0";
            // 
            // o_win_count
            // 
            this.o_win_count.AutoSize = true;
            this.o_win_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.o_win_count.Location = new System.Drawing.Point(253, 420);
            this.o_win_count.Name = "o_win_count";
            this.o_win_count.Size = new System.Drawing.Size(30, 31);
            this.o_win_count.TabIndex = 15;
            this.o_win_count.Text = "0";
            // 
            // draw_count
            // 
            this.draw_count.AutoSize = true;
            this.draw_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.draw_count.Location = new System.Drawing.Point(253, 484);
            this.draw_count.Name = "draw_count";
            this.draw_count.Size = new System.Drawing.Size(30, 31);
            this.draw_count.TabIndex = 16;
            this.draw_count.Text = "0";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(393, 24);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.newGameToolStripMenuItem.Text = "New Game";
            this.newGameToolStripMenuItem.Click += new System.EventHandler(this.newGameToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aToolStripMenuItem
            // 
            this.aToolStripMenuItem.Name = "aToolStripMenuItem";
            this.aToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aToolStripMenuItem.Text = "About";
            this.aToolStripMenuItem.Click += new System.EventHandler(this.aToolStripMenuItem_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::tic_tec_toe_game.Properties.Resources.@__jpg_640x640;
            this.ClientSize = new System.Drawing.Size(393, 541);
            this.Controls.Add(this.draw_count);
            this.Controls.Add(this.o_win_count);
            this.Controls.Add(this.x_win_count);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.u3);
            this.Controls.Add(this.u2);
            this.Controls.Add(this.u1);
            this.Controls.Add(this.t3);
            this.Controls.Add(this.t2);
            this.Controls.Add(this.t1);
            this.Controls.Add(this.k3);
            this.Controls.Add(this.k2);
            this.Controls.Add(this.k1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form5";
            this.ShowInTaskbar = false;
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button k1;
        private System.Windows.Forms.Button k2;
        private System.Windows.Forms.Button k3;
        private System.Windows.Forms.Button t1;
        private System.Windows.Forms.Button t2;
        private System.Windows.Forms.Button t3;
        private System.Windows.Forms.Button u1;
        private System.Windows.Forms.Button u2;
        private System.Windows.Forms.Button u3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label x_win_count;
        private System.Windows.Forms.Label o_win_count;
        private System.Windows.Forms.Label draw_count;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aToolStripMenuItem;
    }
}